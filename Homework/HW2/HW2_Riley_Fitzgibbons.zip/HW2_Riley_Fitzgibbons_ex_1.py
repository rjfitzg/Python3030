'''
Homework 2, Excercise 1
Riley Fitzgibbons
01/30/19
Recursively calls the collatz functions until the number is equal to 1.
'''

def main():
	myNum = int(input("Input a number: "))
	collatz(myNum)

def collatz(num):
	if (num == 1):
		return
	elif (num %2 == 0):
		newNum = int(num/2)
	elif (num %2 == 1):
		newNum = int((num*3) +1)
	print(newNum)
	collatz(newNum)


# Call main
if __name__=="__main__":
	main()
