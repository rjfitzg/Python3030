'''
Homework 2, Excercise 2
Riley Fitzgibbons
01/30/19
Recursively calls the collatz function until the number is equal to one
if the initial input is not an integer, the user is told and then removed from the program
'''

def main():
	try:
		myNum = int(input("Input a number: "))
		collatz(myNum)
	except:
		print("You must input an integer")
	

def collatz(num):
	if (num == 1):
		return
	elif (num %2 == 0):
		newNum = int(num/2)
	elif (num %2 == 1):
		newNum = int((num*3) +1)
	print(newNum)
	collatz(newNum)


# Call main
if __name__=="__main__":
	main()
