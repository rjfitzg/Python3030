'''
Homework 2, Excercise 3
Riley Fitzgibbons
01/30/19
Functions takes in a list and combines the strings in a formatted way to be returned.
'''

def main():
	thisList = ['apples', 'bananas', 'cats', 'donuts', 'eclairs']
	print(printList(thisList))
	

def printList(myList):
	formatStr = ''
	for i in range(len(myList)):
		if (i == (len(myList)-1)):
			formatStr += "and " + myList[i]
		else:
			formatStr += myList[i] + ", "
	return formatStr

# Call main
if __name__=="__main__":
	main()
