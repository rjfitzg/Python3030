'''
Homework 2, Excercise 4
Riley Fitzgibbons
01/30/19
Prints out a predetermined grid to create pixel art
'''

def main():
	grid = [['.', '.', '.', '.', '.', '.'],
        ['.', 'O', 'O', '.', '.', '.'],
        ['O', 'O', 'O', 'O', '.', '.'],
        ['O', 'O', 'O', 'O', 'O', '.'],
        ['.', 'O', 'O', 'O', 'O', 'O'],
        ['O', 'O', 'O', 'O', 'O', '.'],
        ['O', 'O', 'O', 'O', '.', '.'],
        ['.', 'O', 'O', '.', '.', '.'],
        ['.', '.', '.', '.', '.', '.']]
	printGrid(grid)

def printGrid(grid):
	for i in range(0,6):
		for j in range(0,9):
			print(grid[j][i], end='')
		print()

# Call main
if __name__=="__main__":
	main()
