'''
Homework 2, Excercise 5.1
Riley Fitzgibbons
01/30/19
Simplistic guessing game
'''

def main():
	from random import randint
	print("I am thinking of a number between 1-20")
	print("Guess what it is")
	correctNumber = randint(1,20)
	userNumber = -1
	count = 0
	
	# Start guessing game
	while (userNumber != correctNumber):
		count += 1
		userNumber = int(input())
		if (userNumber > correctNumber):
			print("Too high")
		elif (userNumber < correctNumber):
			print("Too low")
	print("Congratz! You guessed %s in %s tries" % (correctNumber, count))

# Call main
if __name__=="__main__":
	main()
