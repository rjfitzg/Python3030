'''
Homework 2, Excercise 5.1
Riley Fitzgibbons
01/30/19
Guessing game but with random low bounds and high bounds.
'''

def main():
	from random import randint
	floor = randint(1,100)
	ceil = randint(floor, floor+100)
	correctNumber = randint(floor,ceil)
	userNumber = -1
	count = 0
	print("I am thinking of a number between %s-%s" % (floor,ceil))
	print("Guess what it is")
	
	while (userNumber != correctNumber):
		count += 1
		userNumber = int(input())
		if (userNumber > correctNumber):
			print("Too high")
		elif (userNumber < correctNumber):
			print("Too low")
	print("Congratz! You guessed %s in %s tries" % (correctNumber, count))

# Call main
if __name__=="__main__":
	main()
