'''
Homework 2, Excercise 1
Riley Fitzgibbons
01/30/19
Guessing game but with random low bounds and high bounds and the computer guesses based on elimation
'''

def main():
	# Import required packages
	import math
	from random import randint
	floor = randint(1,100)
	ceil = randint(floor, floor+100)
	correctNumber = randint(floor,ceil)
	userNumber = -1
	count = 0
	print("I am thinking of a number between %s-%s" % (floor,ceil))
	print("Guess what it is")
	
	#Start with initial guess
	userNumber = math.ceil((floor+ceil)/2)

	while (userNumber != correctNumber):
		count += 1
		print(userNumber)
		if (userNumber > correctNumber):
			ceil = userNumber
			userNumber = math.ceil((correctNumber + floor)/2)
		elif(userNumber < correctNumber):
			floor = userNumber
			userNumber = math.ceil((correctNumber + ceil)/2)

	print("Congratz! You guessed %s in %s tries" % (correctNumber, count))

# Call main
if __name__=="__main__":
	main()
