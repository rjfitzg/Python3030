'''
Homework 3 exercise 1
Riley Fitzgibbons
02/15/19
Takes in an input string and then counts the occurences of each char
'''

# Evaluates the string for each letter
def eval_string(string, let_dict):
    # Go through every letter in the string
    for let in string:
        # If in dictionary, add to its value
        if (let in let_dict):
            let_dict[let] = let_dict[let] + 1
        # If not in dictionary, add to it
        else:
            let_dict[let] = 1

# Prints dictionary in a more readable format
def print_dict(let_dict):
    for item in let_dict:
        print("%s %s" % (item, let_dict[item]))

def main():
    test_string = input("Please input a test string: ")
    let_dict = {}
    eval_string(test_string, let_dict)
    print_dict(let_dict)

if __name__=="__main__":
    main()
