'''
Homework 1 exercise 2
Riley Fitzgibbons
02/15/19
Simple TTT game to show data structures 
'''

def takeTurn(board, P1_turn):
    # Decide whose turn it is
    if (P1_turn):
        let = "X"
    else:
        let = "O"

    # Print board and corresponding number board
    printBoard(board)
    print("\n\n1|2|3 \n_____ \n4|5|6 \n_____ \n7|8|9")
    
    # Select a spot on the board
    spot = input("Select a spot on the board: ")
    if spot in board:
        board[spot] = let
    else:
        print("Sorry not a spot")
    

def printBoard(board):
    count = 1
    # Work through board to print out all values
    for item in board:
        if (count%3 == 0):
            print("%s" % board[item])
            if not (count%9 == 0):
                print("________")
        else:
            print("%s | " % board[item], end="")
        count += 1

def main():
    # Create dictionary for board and needed variables
    board = {'1' : "", '2' : "",'3' : "",'4' : "",
            '5' : "",'6' : "",'7' : "",'8' : "",'9' : ""}
    P1_turn = True
    count = 1

    # Play game for 9 moves
    while (count <10):
        takeTurn(board, P1_turn)
        count += 1
        P1_turn = not P1_turn
    print("Done")

if __name__=="__main__":
    main()
