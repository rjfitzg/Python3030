'''
Homework 3 exercise 3
Riley Fitzgibbons
02/15/19
Simple password manager
'''

def main():
    # Import packages
    import sys

    # Store website argument
    try:
        site_arg = sys.argv[1]
        mass_pass_arg = sys.argv[2]
    except:
        print("Please pass in 2 arguments")
        print("[website] [master_password]")
        sys.exit()
    
    
    # Create website list and password manager
    web_list = {'instagram' : 'qwertyuiop', 'google' : '1qaz2wsx3edc', 
            'facebook' : '0p;/.lo98ik,', 'microsoft' : 'buikjmnhytgvf' }
    mass_pass = 'lolol'
    
    if (mass_pass_arg == mass_pass):

        # If website is in list, print its password, otherwise kick out
        if (site_arg in web_list):
            print("%s password is %s" % (site_arg, web_list[site_arg]))
            try:
                import pyperclip
                pyperclip.copy(web_list[site_arg])
                print("The password has been copied to your clipboard")
            except:
                print("There was an error, copy the password manually")
        else:
            print("Sorry %s is not in password bank" % site_arg)
    else:
        print("Sorry, your master password was not correct")

if __name__=="__main__":
    main()
