'''
Homework 3 Exercise 4
Riley Fitzgibbons
02/15/19
Extremely simple inventory system that allows addition and removal of items
'''

# Adds items to existing categories and new categories
def newItem(inv):
    new_item = input("What item would you like to add? ")
    if (new_item in inv):
        inv[new_item] = inv[new_item] + 1
    else:
        #new_item_quantity = int(input("How many %s? " % new_item))
        inv[new_item] = 1

# Removes a single unit of a category
def removeItem(inv):
    printInv(inv)
    del_item = input("What item would you like to remove? ")
    if (del_item in inv):
        inv[del_item] = inv[del_item] - 1
    else:
        print("Sorry %s is not in your inventory" % del_item)

# Prints current inventory in a nice format
def printInv(inv):
    print("You have...")
    for item in inv:
        print("%s %s" % (inv[item], item))

def main():
    inventory = {'rope' : 1, 'torch' : 6, 'gold' : 42, 'dagger' : 1, 'arrow' : 12 }
    removeItem(inventory)
    printInv(inventory)
    newItem(inventory)
    printInv(inventory)
    print('Done')


if __name__=="__main__":
    main()
