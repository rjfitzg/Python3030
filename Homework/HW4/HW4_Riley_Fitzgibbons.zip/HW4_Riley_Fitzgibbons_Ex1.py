'''
Homework 4 exercise 1
Riley Fitzgibbons
02/16/19
A introduction to classes using: square, circle, rectangle
'''

# Class Definitions
class rectangle():
	def __init__(self, length, width):
		self.length = length
		self.width = width

	def area(self):
		return self.length * self.width

	def diagonal(self):
		import math
		return (math.sqrt(self.length**2 + self.width**2))

	def perimeter(self):
		return (self.length*2 + self.width*2)

class circle():
	def __init__(self, radius):
		self.radius = radius
	
	def area(self):
		import math
		return (self.radius**2 * math.pi)
	
	def perimeter(self):
		#import math.pi as pi
		import math
		return (2 * math.pi * self.radius)

class square():
	def __init__(self, length):
		self.length = length

	def area(self):
		return self.length**2

	def perimeter(self):
		return self.length*4

	def diagonal(self):
		import math
		return (math.sqrt(self.length**2 * 2))



def main():
	def_rect = rectangle(20,10)
	this_circle = circle(def_rect.diagonal()/2)
	print("Rectangle\n	length: %s width: %s"
		% (def_rect.length, def_rect.width))
	print("Circle\n 	radius: %s perimeter %s"
		% (this_circle.radius, this_circle.perimeter()))
	
	print('Done')


# Call main if main
if __name__=="__main__":
	main()
