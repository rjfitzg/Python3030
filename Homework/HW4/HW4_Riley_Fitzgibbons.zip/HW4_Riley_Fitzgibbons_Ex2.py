'''
Homework 4 exercise 2
Riley Fitzgibbons
02/16/19
Reverse iterator class that reversely iterates a list
'''

# Class Definitions
class ReverseIter():
	def __init__(self, this_list):
		self.list = this_list

	def next(self):
		return self.list.pop()

def main():
	it = ReverseIter([5,4,3,2,1])
	print(it.next())
	print(it.next())
	print(it.next())
	print('Done')


# Call main if main
if __name__=="__main__":
	main()
