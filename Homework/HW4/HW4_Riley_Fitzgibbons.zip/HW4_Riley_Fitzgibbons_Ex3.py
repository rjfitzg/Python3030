'''
Homework4 Exercise 3
Riley Fitzgibbons
02/16/19

''

def main():
	print('Done')


# Call main if main
if __name__=="__main__":
	main()
