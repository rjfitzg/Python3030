'''
Homework 5 Excercise 
Riley Fitzgibbons
03/02/19
Calls a decorator function that sleeps for a specified time
'''

# Functions List
def icecream():
    print("I like icecream")

def slowdown(func, time=1):
    from time import sleep
    sleep(time)
    func()

# Main
def main():
    slowdown(icecream, 5)
    print("Done")

# Call main
if __name__=="__main__":
    main()
