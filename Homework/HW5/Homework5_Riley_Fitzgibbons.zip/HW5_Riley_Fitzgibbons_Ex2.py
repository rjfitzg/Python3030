'''
Homework 5 Excercise 
Riley Fitzgibbons
03/02/19
Using the cache function cuts down on the calculation time by a significant factor
'''

def cache(func):
    def wrapper(*args, **kwargs):
        # What is needed in the decorator
        func(*args, **kwargs)
    return wrapper

# Functions List
def fibonacci(num):
    if num < 2:
        return num
    return fibonacci(num - 1) + fibonacci(num - 2)

# Main
def main():
    withCache = cache(fibonacci)
    withCache(10)
    print("Done")

# Call main
if __name__=="__main__":
    main()
