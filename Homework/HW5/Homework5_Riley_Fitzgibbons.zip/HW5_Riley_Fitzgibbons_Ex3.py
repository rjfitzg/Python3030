'''
Homework 5 Excercise 
Riley Fitzgibbons
03/02/19
Searches for Phone numbers and emails from a string copied in from the clipboard
'''

# Functions List
def isPhoneNumber(testStr):
    import re
    phone_re = re.compile(r'\d{3}-\d{3}-\d{4}', re.VERBOSE)
    return phone_re.findall(testStr)

def isEmail(testStr):
   import re
   email_re = re.compile(r'\b[\w.-]+?@\w+?\.\w+?\b', re.VERBOSE)
   return email_re.findall(testStr)


# Main
def main():
    # Import necesary packags
    import pyperclip as pc

    # Import the string from clipboard
    # testStr = pc.paste() # Continued to get errors the my OS does not support copy paste, used made up test string instead
    testStr = 'stuffy stuff 303-902-6016 thing thingy things rfitzgib@uccs.edu other stuff not about me. another email goes here johnjacob@gmail.edu along with another phone number 452-987-3174 stuff'

    print(isPhoneNumber(testStr))
    print(isEmail(testStr))
    print("Done")

# Call main
if __name__=="__main__":
    main()
