'''
Homework 5 Excercise 
Riley Fitzgibbons
03/02/19

'''

# Functions List

'''
(?=.*[a-z])     lowercase
(?=.*[A-Z])	uppercase
(?=.*[0-9])     number
(?=.{8,})       length
'''
def strongPass(password):
    import re
    pass_re = re.compile(r'^(?=.*?\d)(?=.*?[A-Z])(?=.*?[a-z])[A-Za-z\d]{8,}$')
    if (pass_re.match(password)) is not None:
        print("good password")
    else:
        print('bad password')

# Main
def main():
    passwords = [ 'cowmilk', 'sTr0ngpA55', 'g04Tm1lK' ]
    for attempt in passwords:
        strongPass(attempt)
    print("Done")

# Call main
if __name__=="__main__":
    main()
