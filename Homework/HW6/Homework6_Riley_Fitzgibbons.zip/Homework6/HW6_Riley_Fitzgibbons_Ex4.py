'''
Homework 6 Exercise 1
Riley Fitzgibbons
03/06/19

'''

# Functions 


# Main
def main():
    print('Done')

if __name__=="__main__":
    main()
