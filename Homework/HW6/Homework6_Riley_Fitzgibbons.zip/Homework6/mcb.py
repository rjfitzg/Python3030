'''
Homework 6 Exercise 1
Riley Fitzgibbons
03/06/19

'''

# Functions 


# Main
def main():
    # Import frameworks
    import sys
    import os

    # Check command line args
    if (len(sys.argv) < 2): # if incorrect args, tell user how to use program
        print("Please pass arguments")
        print("mcb.py [save, list, delete, deleteall] [keyword]")
        import sys
        sys.exit()

    # Load in notework with saved keywords and pyperclip
    # import pyperclip
    # toSave = pyperclip.paste()
    toSave = 'some stuff in clipboard'
    writeFileName = 'mcb_text.txt'
    keyFile = open(writeFileName, 'r+')
    keyword = sys.argv[2]

    if (str(sys.argv[1]) == 'deleteall'):
        # Delete file and close program
        keyFile.close()
        os.remove(writeFileName)
        sys.exit() 
    elif (str(sys.argv[1]) == 'save'):
        # Save keyword and clipboard entry
        keyFile.write((sys.argv[2]+ toSave))
    elif (str(sys.argv[1]) == 'list'):
        # List file for user
        print(keyFile.read())
    elif (str(sys.argv[1]) == 'delete'):
        # Run through lines of file and delete the one that matches keyword
        lines = keyFile.readlines()
        for line in lines:
            if keyword not in line:
                keyFile.write(line)
                
    else:
        print("Accepted keywords are: save, list, delete, deleteall")

    keyFile.close()

    print('Done')

if __name__=="__main__":
    main()
