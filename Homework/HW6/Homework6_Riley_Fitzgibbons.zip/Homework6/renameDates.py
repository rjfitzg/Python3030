'''
Homework 6 Excercise 2
Riley Fitzgibbons
03/09/19
Changes the name of files from mm/dd/yyy to dd/mm/yyy
'''
# Functions 
def SearchCurrDir():
    # Searches the needed directory
    import os
    for root, dirs, files in os.walk("."):
        for aFile in files:
            checkRegex(aFile)

def checkRegex(aFile):
    # Creates and checks the regex
    import re
    americanDate = re.compile(r'(?:(?:(?:0?[13578]|1[02])(\/|-|\.)31)\1|(?:(?:0?[1,3-9]|1[0-2])(\/|-|\.)(?:29|30)\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:0?2(\/|-|\.)29\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:(?:0?[1-9])|(?:1[0-2]))(\/|-|\.)(?:0?[1-9]|1\d|2[0-8])\4(?:(?:1[6-9]|[2-9]\d)?\d{2})') # Pulled from a website
    try:
        # If there is a match to the regex, then send to renaming function
        americanDate.match(aFile)[0]
        changeDateName(str(aFile))
    except:
        pass

def changeDateName(origFile):
    import shutil
    
    # Change the month and the day in the files
    destFile = origFile
    destFile[0] = origFile[3]
    destFile[1] = origFile[4]
    destFile[3] = origFile[0]
    destFile[4] = origFile[1]

    # Replace file with its corrected name
    shutil.move(origFile, destFile)

#Main
def main():
    SearchCurrDir()
    print('Done')

if __name__=="__main__":
    main()
