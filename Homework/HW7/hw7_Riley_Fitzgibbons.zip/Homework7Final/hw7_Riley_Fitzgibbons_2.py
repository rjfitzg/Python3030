'''
Homework 7 Excercise 1
Riley Fitzgibbons
03/12/19
Save images from a search on a file site (imgur)
'''
# Functions
def keywordSearch(keyword):
    # Import Necesary packages
    from bs4 import BeautifulSoup as bs
    import requests

    # Set variables and gather web data
    url = "https://imgur.com/search?q="
    req = requests.get(url + keyword)
    soup = bs(req.text, features="html.parser")
    count = 1       # Count
    countLimit = 3  # Set this to change the number of images to save.
    tags=soup.findAll('img')
    for tag in tags:
        print(tag['src']) # Cant figure out how to remove url from 
    download_file(str.join('',set(tag['src'] for tag in tags)))


# Code gathered from stackoverflow, personal comments
def download_file(url): 
    import shutil 
    import requests
    # Remove part of url to gather exclusively filename
    local_filename = url.split('/')[-1]
    # Get a request object to manipulate
    r = requests.get(url, stream=True)
    # For the name of the current file, save the file
    with open(local_filename, 'wb') as f:
        shutil.copyfileobj(r.raw, f) 
       

# Main
def main():
    #Import packages
    import sys

    #try:
    #keyword = sys.argv[1]
    keywordSearch(sys.argv[1])
    #except:
    #    print('ugh')

    print("Done")

# Call main, if main
if __name__=="__main__":
    main()
