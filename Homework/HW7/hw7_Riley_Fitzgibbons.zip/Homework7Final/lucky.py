'''
Homework 7 Excercise 1
Riley Fitzgibbons
03/12/19
Build a webscrapper that opens search links in new tabs
'''
# Functions
def keywordSearch(keyword):
    # Import Necesary packages
    from bs4 import BeautifulSoup as bs
    import requests
    import webbrowser

    # Set variables and gather web data
    url = "https://www.bing.com/search?q="
    req = requests.get(url + keyword)
    soup = bs(req.text, features="html.parser")
    count = 1       # Count
    countLimit = 3  # Set this to change the number of tabs that open

    for result in soup.select('.b_algo', href=True):
        # stuff = result.find(href=True) # Cannot figure out this part
        stuff = "https://www.google.com/"
        # Open web browser
        webbrowser.open(stuff)
        if (count==countLimit):
            return
        else:
            count += 1


# Main
def main():
    #Import packages
    import sys

    #try:
    #keyword = sys.argv[1]
    keywordSearch(sys.argv[1])
    #except:
    #    print('ugh')

    print("Done")

# Call main, if main
if __name__=="__main__":
    main()
